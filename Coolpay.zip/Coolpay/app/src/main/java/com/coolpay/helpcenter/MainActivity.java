package com.coolpay.helpcenter;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private CardView cardview1;
	private LinearLayout linear4;
	private MaterialButton materialbutton3;
	private MaterialButton materialbutton4;
	private LinearLayout linear3;
	private TextView textview1;
	private MaterialButton materialbutton1;
	private LinearLayout linear5;
	private MaterialButton materialbutton2;
	
	private SharedPreferences prefs;
	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		cardview1 = findViewById(R.id.cardview1);
		linear4 = findViewById(R.id.linear4);
		materialbutton3 = findViewById(R.id.materialbutton3);
		materialbutton4 = findViewById(R.id.materialbutton4);
		linear3 = findViewById(R.id.linear3);
		textview1 = findViewById(R.id.textview1);
		materialbutton1 = findViewById(R.id.materialbutton1);
		linear5 = findViewById(R.id.linear5);
		materialbutton2 = findViewById(R.id.materialbutton2);
		prefs = getSharedPreferences("Help Center", Activity.MODE_PRIVATE);
		
		materialbutton3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				prefs.edit().putString("isFirstTime", "false").commit();
				intent.setClass(getApplicationContext(), ChatMsgActivity.class);
				startActivity(intent);
				finish();
			}
		});
		
		materialbutton4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_open_chrome("https://doc-hosting.flycricket.io/coolpay-help-center-terms-of-use/4382b456-ef40-4e20-a5f9-0b779ccdf827/terms");
			}
		});
		
		materialbutton2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_open_chrome("https://doc-hosting.flycricket.io/coolpay-help-center-privacy-policy/bf33504b-107f-48f0-b2a6-f211c5de0a69/privacy");
			}
		});
	}
	
	private void initializeLogic() {
		if (prefs.contains("isFirstTime")) {
			intent.setClass(getApplicationContext(), ChatMsgActivity.class);
			startActivity(intent);
			finish();
		}
	}
	
	public void _open_chrome(final String _string) {
		androidx.browser.customtabs.CustomTabsIntent.Builder builder = new androidx.browser.customtabs.CustomTabsIntent.Builder();
		androidx.browser.customtabs.CustomTabsIntent customTabsIntent = builder.build();
		customTabsIntent.launchUrl(getCurrentContext(this), Uri.parse(_string));
		
		
		
	}
	
	public Context getCurrentContext(Context c) {
		    return c;
	}
	public Context getCurrentContext(Fragment c) {
		    return c.getActivity();
	}
	public Context getCurrentContext(DialogFragment c) {
		    return c.getActivity();
	}
	
	
	{
	}
	
}