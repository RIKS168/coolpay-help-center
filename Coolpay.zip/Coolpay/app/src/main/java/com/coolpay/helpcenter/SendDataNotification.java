package com.coolpay.helpcenter;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;

public class SendDataNotification {
    private static FirebaseDatabase _firebase = FirebaseDatabase.getInstance();

    /* renamed from: db */
    private static DatabaseReference f721db = _firebase.getReference("Notification");
    private static HashMap<String, Object> map = new HashMap<>();
    private Context mContext;

    public SendDataNotification(Context context) {
        this.mContext = context;
        initialize();
    }

    private void initialize() {
        FirebaseApp.initializeApp(this.mContext);
    }

    static void sendDataNotification(String str, String str2) {
        map = new HashMap<>();
        map.put("Seen", "No");
        f721db.child("Notification").updateChildren(map);
    }
}
