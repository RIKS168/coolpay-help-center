package com.coolpay.helpcenter;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;

public class SendData {
    private static FirebaseDatabase _firebase = FirebaseDatabase.getInstance();

    /* renamed from: db */
    private static DatabaseReference f720db = _firebase.getReference("SubGo");
    private static HashMap<String, Object> map = new HashMap<>();
    private Context mContext;

    public SendData(Context context) {
        this.mContext = context;
        initialize();
    }

    private void initialize() {
        FirebaseApp.initializeApp(this.mContext);
    }

    static void sendData(String str, String str2) {
        map = new HashMap<>();
        map.put("Notification", str);
        map.put("Header", str2);
        f720db.push().updateChildren(map);
    }
}
